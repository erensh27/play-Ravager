#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
: "${EMSDK:=/home/sandbox/emsdk}"
source "$EMSDK/emsdk_env.sh" >/dev/null
cd "$ROOT"
SRC=(src/bitboard.c src/board.c src/movegen.c src/see.c src/evaluate.c src/params.c src/tt.c src/search.c src/nnue.c src/tb_syzygy_web.c src/web_api.c)
emcc "${SRC[@]}" -O3 -std=c11 -Isrc -s MODULARIZE=1 -s EXPORT_ES6=1 -s ENVIRONMENT=web,worker -s ALLOW_MEMORY_GROWTH=1 -s INITIAL_MEMORY=67108864 -s FILESYSTEM=1 --embed-file web/engine/ravager.nnue@/ravager.nnue -s EXPORTED_FUNCTIONS='["_ravager_init","_ravager_bestmove","_ravager_eval","_ravager_nnue_ready","_malloc","_free"]' -s EXPORTED_RUNTIME_METHODS='["UTF8ToString","stringToUTF8","lengthBytesUTF8"]' -o web/engine/ravager.js
