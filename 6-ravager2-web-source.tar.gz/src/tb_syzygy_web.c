#include "tb_syzygy.h"
int syzygy_probe_limit = 0;
bool syzygy_50move_rule = true;
uint64_t syzygy_hits = 0;
void syzygy_init(const char *path) { (void)path; }
bool syzygy_available(void) { return false; }
int syzygy_largest(void) { return 0; }
bool syzygy_probe_wdl(const Board *b, int ply, int *score) { (void)b; (void)ply; (void)score; return false; }
Move syzygy_probe_root(const Board *b) { (void)b; return NO_MOVE; }
