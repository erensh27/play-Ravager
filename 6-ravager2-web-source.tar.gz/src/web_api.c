#include "bitboard.h"
#include "tt.h"
#include "search.h"
#include "nnue.h"

bool nnue_load_file(const char *path);
bool is_insufficient_material(const Board *b);

static Board web_board;
static char bestmove_buf[8];
static int ready = 0;

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define WEB_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define WEB_EXPORT
#endif

WEB_EXPORT int ravager_init(void) {
    if (ready) return 1;
    board_init_all();
    init_lmr_table();
    tt_alloc(32);
    search_reset_tables();
    nnue_enabled = true;
    if (!nnue_load_file("/ravager.nnue")) return 0;
    ready = parse_fen(&web_board, STARTPOS_FEN) ? 1 : 0;
    return ready;
}

WEB_EXPORT const char *ravager_bestmove(const char *fen, int movetime_ms) {
    bestmove_buf[0] = 0;
    if (!ready && !ravager_init()) return bestmove_buf;
    if (!fen || !parse_fen(&web_board, fen)) return bestmove_buf;
    search_set_game_history(NULL, 0);
    search_reset_tables();
    search_verbose = 0;
    search_max_depth = 100;
    if (movetime_ms < 50) movetime_ms = 50;
    if (movetime_ms > 5000) movetime_ms = 5000;
    search_soft_ms = movetime_ms;
    search_hard_ms = movetime_ms + 30;
    search_iterative_deepening(&web_board);
    if (search_root_best != NO_MOVE) {
        const char *s = move_to_str(search_root_best);
        strncpy(bestmove_buf, s, sizeof(bestmove_buf)-1);
        bestmove_buf[sizeof(bestmove_buf)-1] = 0;
    }
    return bestmove_buf;
}

WEB_EXPORT int ravager_eval(const char *fen) {
    if (!ready && !ravager_init()) return 0;
    if (!fen || !parse_fen(&web_board, fen)) return 0;
    return nnue_evaluate_board(&web_board);
}

WEB_EXPORT int ravager_nnue_ready(void) { return ready && nnue_loaded && nnue_enabled; }
